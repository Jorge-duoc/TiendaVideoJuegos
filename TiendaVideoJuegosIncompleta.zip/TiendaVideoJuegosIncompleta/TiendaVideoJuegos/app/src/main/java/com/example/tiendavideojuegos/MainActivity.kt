package com.example.tiendavideojuegos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.tiendavideojuegos.ui.theme.TiendaVideoJuegosTheme
import com.example.tiendavideojuegos.view.FormularioJuegoScreen
import com.example.tiendavideojuegos.view.ResumenJuegoScreen
import com.example.tiendavideojuegos.viewmodel.JuegoViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TiendaVideoJuegosTheme {
                JuegoApp()
            }
        }
    }
}

@Composable @Preview
fun JuegoApp() {
    val navController = rememberNavController()
    val juegoViewModel: JuegoViewModel = viewModel()

    NavHost(navController = navController, startDestination = "formulario") {
        composable("formulario") {
            FormularioJuegoScreen(navController = navController, viewModel = juegoViewModel)
        }
        composable("resumen") {
            ResumenJuegoScreen(viewModel = juegoViewModel)
        }
        composable(route="compra"){
            CompraJuegoScreen(viewModel = juegoViewModel)
        }
    }
}




