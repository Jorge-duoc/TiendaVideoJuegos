package com.example.tiendavideojuegos.view

import android.os.VibrationEffect
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.tiendavideojuegos.viewmodel.JuegoViewModel
import androidx.navigation.NavController
import com.example.tiendavideojuegos.viewmodel.JuegoViewModel
import androidx.compose.ui.platform.LocalContext
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.Context

@Composable
fun ResumenJuegoScreen(viewModel: JuegoViewModel) {
    val estado by viewModel.estado.collectAsState()

    Column(
        Modifier
            .padding(16.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Resumen del videojuego", style = MaterialTheme.typography.headlineMedium)
        Text("🎮 Nombre: ${estado.nombre}")
        Text("🎭 Género: ${estado.genero}")
        Text("💰 Precio: ${estado.precio}")
        Text("📝 Descripción: ${estado.descripcion}")
        Text("✅ Términos aceptados: ${if (estado.aceptaTerminos) "Sí" else "No"}")
    }
    Button(
        onClick = {
            if (viewModel.validarFormulario()) {
                vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
                navController.navigate("CompraJuego")
            }
        },
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("Comprar")
    }
}