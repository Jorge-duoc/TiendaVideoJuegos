package com.example.tiendavideojuegos.viewmodel

import androidx.lifecycle.ViewModel
import com.example.tiendavideojuegos.model.JuegoErrores
import com.example.tiendavideojuegos.model.JuegoUIState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class JuegoViewModel : ViewModel() {

    private val _estado = MutableStateFlow(JuegoUIState())
    val estado: StateFlow<JuegoUIState> = _estado

    fun onNombreChange(valor: String) {
        _estado.update { it.copy(nombre = valor, errores = it.errores.copy(nombre = null)) }
    }

    fun onGeneroChange(valor: String) {
        _estado.update { it.copy(genero = valor, errores = it.errores.copy(genero = null)) }
    }

    fun onPrecioChange(valor: String) {
        _estado.update { it.copy(precio = valor, errores = it.errores.copy(precio = null)) }
    }

    fun onDescripcionChange(valor: String) {
        _estado.update { it.copy(descripcion = valor, errores = it.errores.copy(descripcion = null)) }
    }

    fun onAceptarTerminosChange(valor: Boolean) {
        _estado.update { it.copy(aceptaTerminos = valor) }
    }

    fun validarFormulario(): Boolean {
        val estadoActual = _estado.value
        val errores = JuegoErrores(
            nombre = if (estadoActual.nombre.isBlank()) "Campo obligatorio" else null,
            genero = if (estadoActual.genero.isBlank()) "Campo obligatorio" else null,
            precio = if (estadoActual.precio.toDoubleOrNull() == null) "Debe ser numérico" else null,
            descripcion = if (estadoActual.descripcion.isBlank()) "Campo obligatorio" else null
        )

        val hayErrores = listOfNotNull(
            errores.nombre,
            errores.genero,
            errores.precio,
            errores.descripcion
        ).isNotEmpty()

        _estado.update { it.copy(errores = errores) }
        return !hayErrores && estadoActual.aceptaTerminos
    }
}