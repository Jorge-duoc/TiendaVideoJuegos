package com.example.tiendavideojuegos.model

data class JuegoUIState(
    val nombre: String = "",
    val genero: String = "",
    val precio: String = "",
    val descripcion: String = "",
    val aceptaTerminos: Boolean = false,
    val errores: JuegoErrores = JuegoErrores()
)

data class JuegoErrores(
    val nombre: String? = null,
    val genero: String? = null,
    val precio: String? = null,
    val descripcion: String? = null
)